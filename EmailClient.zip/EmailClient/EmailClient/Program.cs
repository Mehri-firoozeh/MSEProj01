﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace EmailClient
{
    class Program
    {
        static void Main(string[] args)
        {

           // new ImapService().ParseNewEmail();
            var emailObject= new ImapService().ParseNewEmail();
            //byte[] data = Encoding.UTF8.GetBytes(emailObject.ToString());
            //string result = "";

            //using (var client = new WebClient())
            //{
            //    client.Headers[HttpRequestHeader.ContentType] = "application/json";
            //    byte[] response = client.UploadData("http://localhost:64747/Home/ProjectList", "ProjectList", data);
            //    result = Encoding.UTF8.GetString(response);
            //}
            //Console.WriteLine(result);

            Console.ReadLine();
        }
    }
}
