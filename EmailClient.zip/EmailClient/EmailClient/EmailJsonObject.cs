﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmailClient
{
    class EmailJsonObject
    {
        public string ProjectID;
        public string PhaseID;
        public string VerticalID;        
        public string UpdateKey;
        public string UpdateValue;
        public DateTime RecordedDate;

    }
}
